=====================
1. COPYRIGHT
=====================
Copyright (C) 2016-2017
This file is part of the Hierarchical Data Format query language (HDFql)
For more information about HDFql, please visit the website http://www.hdfql.com


=====================
2. DESCRIPTION
=====================
HDFql stands for "Hierarchical Data Format query language" and is the first
tool that enables users to manage HDF files through a high-level language.
This language was designed to be simple to use and similar to SQL thus
dramatically reducing the learning effort. HDFql can be seen as an alternative
to the C API (which contains more than 400 low-level functions that are far
from easy to use!) and to existing wrappers for C++, Java, Python, C# and
Fortran for manipulating HDF files. Whenever possible, it automatically uses
parallelism to speed-up operations hiding its inherent complexity from the
user.

As an example, imagine that one needs to create an HDF file named "myFile.h5"
and, inside it, a group named "myGroup" containing an attribute named
"myAttribute" of type float with a value of 12.4. Using the C API, it could be
implemented like this:

   hid_t file;
   hid_t group;
   hid_t dataspace;
   hid_t attribute;
   hsize_t dimension;
   float value;
   H5Fcreate("myFile.h5", H5F_ACC_EXCL, H5P_DEFAULT, H5P_DEFAULT);
   file = H5Fopen("myFile.h5", H5F_ACC_RDWR, H5P_DEFAULT);
   group = H5Gcreate(file, "myGroup", H5P_DEFAULT, H5P_DEFAULT, H5P_DEFAULT);
   dimension = 1;
   dataspace = H5Screate_simple(1, &dimension, NULL);
   attribute = H5Acreate(group, "myAttribute", H5T_NATIVE_FLOAT, dataspace, H5P_DEFAULT, H5P_DEFAULT);
   value = 12.4;
   H5Awrite(attribute, H5T_NATIVE_FLOAT, &value);

In HDFql, the same example can easily be implemented just by doing this:

   create file myFile.h5
   use file myFile.h5
   create group myGroup
   create attribute myGroup/myAttribute as float default 12.4


=====================
3. ORGANIZATION
=====================
This distribution is organized as follows:

   HDFql-x.y.z
        |
        + example (contains examples in C, C++, Java, Python, C# and Fortran)
        |
        + include (contains HDFql C and C++ header files)
        |
        + lib (contains HDFql C release/debug static and shared libraries)
        |
        + bin (contains HDFql command-line interface and a proper launcher)
        |
        + wrapper (contains wrappers for C++, Java, Python, C# and Fortran)
        |
        + doc (contains HDFql reference manual)
        |
        - LICENSE.txt (file that contains information about HDFql license)
        |
        - RELEASE.txt (file that contains information about HDFql releases)
        |
        - README.txt (refers to the present file)


=====================
4. USAGE
=====================
4.1 C
HDFql can be used in C programs through static and shared libraries. These
libraries are stored in the directory "lib". In the C program, include the
header file "HDFql.h" and make sure the compiler finds the HDFql library in
order for the program to be successfully compiled. For a complete documentation
about the library, please visit the website http://www.hdfql.com/documentation.

4.2 C++, Java, Python, C# and Fortran
HDFql can also be used in C++, Java, Python, C# and Fortran programs through
appropriate wrappers. These are stored in the directories "cpp", "java",
"python", "csharp" and "fortran" which are under the directory "wrapper". Also,
examples on how to use these wrappers can be found in the directory "example".
For a complete documentation about the wrappers, please visit the website
http://www.hdfql.com/documentation.

4.3 Command-Line Interface
A command-line interface named "HDFqlCLI" is available and can be used for
manipulating HDF files. It is stored in the directory "bin". To launch the
command-line interface, open a terminal ("cmd" if in Windows, "xterm" if in
Linux, or "Terminal" if in Mac OS X), go to the directory "bin", and type
"HDFqlCLI" (if in Windows) or "./HDFqlCLI" (if in Linux/Mac OS X). The list of
parameters accepted by the command-line interface can be seen by launching it
with the parameter "--help".

